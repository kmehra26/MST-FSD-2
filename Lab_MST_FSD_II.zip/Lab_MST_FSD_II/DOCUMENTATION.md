# Social Media Post Composer — Experiment & Technical Documentation

---

## 1. Experiment Aim

**Aim:**  
To design, develop, and evaluate a responsive, interactive **Social Media Post Composer** using **React** that allows users to draft, validate, and preview posts targeted for different social platforms (**Twitter / X** and **LinkedIn**).

### Specific Objectives:
1. **Dynamic Character Limiting**: Enforce platform-specific character limits dynamically:
   - **Twitter / X**: Max **280 characters**.
   - **LinkedIn**: Max **3,000 characters**.
2. **Real-time State Management**: Monitor and compute the active character count, remaining character budget, word count, and reading time on every keystroke.
3. **Visual Limit Feedback & Error Handling**: Render an immediate visual error banner and styling state (shake animation, red border, highlighted excess count) whenever character limits are breached.
4. **Live Social Card Synchronization**: Display a synchronized, realistic live preview of the post styled as an authentic Twitter or LinkedIn feed card.
5. **Usability Features**: Implement quick sample loaders, hashtag inserters, and one-click clipboard copying with toast notifications.

---

## 2. Folder Structure

```
Lab_MST_FSD_II/
├── index.html                     # HTML5 entry point with Google Fonts & SEO metadata
├── package.json                   # Dependencies, scripts, and build configuration
├── vite.config.js                 # Vite bundler configuration & local server setup
├── DOCUMENTATION.md               # Complete experiment report and system architecture
├── node_modules/                  # Installed npm packages (React, Lucide, Vite, etc.)
└── src/
    ├── main.jsx                   # React DOM root render entry point
    ├── App.jsx                    # Top-level state container & responsive layout
    ├── index.css                  # Custom Design System, Glassmorphism & Animations
    ├── constants/
    │   └── platforms.js           # Configuration metadata, limits, authors & sample posts
    └── components/
        ├── Header.jsx             # Top navigation banner with platform limit chips
        ├── PlatformSelector.jsx   # Interactive radio button toggles for Twitter/LinkedIn
        ├── PostComposer.jsx       # Main textarea, progress rings, counters & error alerts
        ├── SocialPreview.jsx      # Realistic live Twitter/LinkedIn post card mockups
        ├── PlatformGuide.jsx      # Platform-specific writing tips & character rules
        ├── Icons.jsx              # Vector SVG brand icons for Twitter/X and LinkedIn
        └── Toast.jsx              # Floating status notification for user feedback
```

### Module Breakdown:

| File / Folder | Role & Description |
| :--- | :--- |
| `src/App.jsx` | Holds global post state (`postText`, `selectedPlatform`), copy/clear actions, and coordinates child views. |
| `src/components/PostComposer.jsx` | Houses the controlled `<textarea>`, real-time character math, SVG circular meter, progress bar, error alerts, and action buttons. |
| `src/components/PlatformSelector.jsx` | Tab selector that lets users switch between Twitter and LinkedIn, triggering immediate recalculation of limits. |
| `src/components/SocialPreview.jsx` | Visual mock of how the drafted post will appear live on Twitter or LinkedIn with interactive likes and hashtag highlighting. |
| `src/components/PlatformGuide.jsx` | Informational card showing platform best practices, ideal lengths, and hard limits. |
| `src/components/Icons.jsx` | Pixel-perfect vector SVGs for Twitter/X and LinkedIn. |
| `src/constants/platforms.js` | Single source of truth for platform parameters (limits, colors, placeholder text, author bios). |
| `src/index.css` | Comprehensive CSS variables, glassmorphic dark theme, responsive grid, and animation keyframes. |

---

## 3. System Architecture

The application follows **React's Unidirectional Data Flow** architecture. State is lifted to the top-level `App` component and propagated down via props. Child components invoke callback handlers to update state, triggering reactivity across all components.

```mermaid
graph TD
    subgraph State Container [App.jsx]
        StateText["postText: string"]
        StatePlatform["selectedPlatform: 'twitter' | 'linkedin'"]
        StateToast["toastState: message, visible"]
    end

    subgraph Constants [platforms.js]
        PlatformConfig["PLATFORMS Config (Twitter: 280, LinkedIn: 3000)"]
    end

    StateContainer -->|postText, selectedPlatform| Header["Header.jsx"]
    StateContainer -->|selectedPlatform, onSelectPlatform| PlatformSelector["PlatformSelector.jsx"]
    StateContainer -->|postText, setPostText, selectedPlatform, onCopy, onClear| PostComposer["PostComposer.jsx"]
    StateContainer -->|postText, selectedPlatform| SocialPreview["SocialPreview.jsx"]
    StateContainer -->|selectedPlatform| PlatformGuide["PlatformGuide.jsx"]
    StateContainer -->|message, visible| Toast["Toast.jsx"]

    PlatformConfig -.-> PostComposer
    PlatformConfig -.-> SocialPreview
    PlatformConfig -.-> PlatformGuide
```

### Architectural Highlights:
1. **Single Source of Truth**: `platforms.js` centrally manages platform constraints (`280` for Twitter, `3000` for LinkedIn).
2. **Reactive Validation Engine**: Character metrics are derived directly from `postText.length` and active `PLATFORMS[selectedPlatform].limit`. No redundant state prevents desynchronization bugs.
3. **Pure Presentation Layers**: `SocialPreview` and `PlatformGuide` consume state passively to reflect live draft changes in real time.

---

## 4. Application Workflow

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant App as App.jsx
    participant Selector as PlatformSelector.jsx
    participant Composer as PostComposer.jsx
    participant Preview as SocialPreview.jsx

    User->>App: Opens Application
    App->>Composer: Initialize with default text & Twitter selected (Limit: 280)
    App->>Preview: Render Twitter Mockup

    rect rgb(30, 41, 59)
        note over User,Composer: Scenario 1: Typing & Limit Validation
        User->>Composer: Types post content in Textarea
        Composer->>App: setPostText(newText)
        App->>Composer: Pass updated postText
        Composer->>Composer: Compute charCount = postText.length
        alt charCount <= Limit
            Composer->>Composer: Render green/blue progress ring & remaining count
            Composer->>Composer: Enable "Publish" button
        else charCount > Limit
            Composer->>Composer: Trigger Shake Animation
            Composer->>Composer: Render Red Error Banner with exact excess (+N chars)
            Composer->>Composer: Disable "Publish" button
        end
        App->>Preview: Synchronize text in live card with highlighted tags
    end

    rect rgb(15, 23, 42)
        note over User,Selector: Scenario 2: Switching Platform
        User->>Selector: Clicks "LinkedIn"
        Selector->>App: setSelectedPlatform('linkedin')
        App->>Composer: Update active limit to 3,000 characters
        Composer->>Composer: Re-evaluate: charCount <= 3000
        Composer->>Composer: Clear Twitter error state & adjust progress ring
        App->>Preview: Switch Mockup to LinkedIn format (avatar, headline, reactions)
    end

    rect rgb(30, 41, 59)
        note over User,Composer: Scenario 3: Copy & Toast Feedback
        User->>Composer: Clicks "Copy Text"
        Composer->>App: onCopy()
        App->>App: Writes to navigator.clipboard
        App->>User: Display floating success toast ("Copied to clipboard!")
    end
```

### Workflow Step-by-Step Explanation:

1. **Initialization**:
   - The application mounts with default text, selecting **Twitter / X** as the initial target.
   - Character count is calculated against the 280-character maximum.
2. **User Input / Textarea Change**:
   - As the user types, the `onChange` event updates `postText`.
   - The composer computes:
     $$\text{Character Count} = \text{postText.length}$$
     $$\text{Remaining Characters} = \text{Limit} - \text{Character Count}$$
     $$\text{Percentage} = \min\left(\frac{\text{Character Count}}{\text{Limit}} \times 100, 100\right)$$
3. **Validation & Visual Trigger**:
   - **Normal ($\le 79\%$)**: Circular ring and progress bar show platform theme color.
   - **Warning ($80\% - 100\%$)**: Meter shifts to amber warning color; warning pill displays remaining balance.
   - **Exceeded ($> 100\%$)**:
     - Red glowing border wraps the composer.
     - Shake micro-animation triggers.
     - Red Error Banner appears detailing the exact overflow count ($+\Delta$ chars).
     - "Publish" button is automatically disabled to prevent invalid submissions.
4. **Platform Switch**:
   - When switching to **LinkedIn**, the limit extends from `280` to `3,000`.
   - Previously exceeding text for Twitter immediately passes LinkedIn's threshold, clearing error alerts instantly.
5. **Live Social Card Synchronization**:
   - The right column automatically parses and highlights hashtags (`#tag`), user mentions (`@user`), and URLs.
   - Engagement counters (Likes, Comments, Reposts) allow interactive simulation.

---

## 5. Technical Validation Rules Summary

| Feature | Twitter / X Configuration | LinkedIn Configuration |
| :--- | :--- | :--- |
| **Max Limit** | **280 characters** | **3,000 characters** |
| **Warning Threshold** | $\ge 224$ characters ($80\%$) | $\ge 2,400$ characters ($80\%$) |
| **Error Trigger** | $\ge 281$ characters | $\ge 3,001$ characters |
| **Error Message** | *"Exceeds 280 character limit by X chars"* | *"Exceeds 3,000 character limit by X chars"* |
| **Primary Theme Color** | `#1d9bf0` (Twitter Sky Blue) | `#0a66c2` (LinkedIn Royal Blue) |
| **Preview Format** | Single Tweet card with handle & verified badge | Full Feed article post with headline & reactions |

---

## 6. Conclusion

The React Post Composer fulfills all core functional requirements:
- Controlled, multi-line `<textarea>` input.
- Real-time character monitoring and limit switching between Twitter (280) and LinkedIn (3000).
- Dynamic error message alerts on boundary violations.
- Enhanced UX via interactive progress rings, live preview cards, and clipboard utilities.
