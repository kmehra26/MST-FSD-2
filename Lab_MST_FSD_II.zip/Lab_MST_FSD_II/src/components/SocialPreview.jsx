import React, { useState } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Repeat2, 
  Bookmark, 
  Share, 
  ThumbsUp, 
  MessageSquare, 
  Send as SendIcon, 
  MoreHorizontal, 
  Globe, 
  CheckCircle2,
  Sparkles,
  Eye,
  BadgeCheck
} from 'lucide-react';
import { PLATFORMS } from '../constants/platforms';

export default function SocialPreview({ postText, selectedPlatform }) {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(42);
  const [activePreviewTab, setActivePreviewTab] = useState(selectedPlatform);

  // Keep preview tab in sync if selectedPlatform changes, unless manually overridden
  React.useEffect(() => {
    setActivePreviewTab(selectedPlatform);
  }, [selectedPlatform]);

  const config = PLATFORMS[activePreviewTab];
  const isOverLimit = postText.length > config.limit;

  const handleToggleLike = () => {
    setLiked(!liked);
    setLikeCount(prev => liked ? prev - 1 : prev + 1);
  };

  // Helper to format text with highlighted hashtags, mentions, and links
  const formatContent = (text) => {
    if (!text) {
      return (
        <span className="placeholder-text">
          {activePreviewTab === 'twitter' 
            ? 'Your Tweet will appear here in real-time as you type...' 
            : 'Your LinkedIn post preview will appear here in real-time...'}
        </span>
      );
    }

    // Split text by hashtags, mentions, and URLs
    const parts = text.split(/((?:#|@)[a-zA-Z0-9_]+|https?:\/\/[^\s]+)/g);
    return parts.map((part, index) => {
      if (part.startsWith('#') || part.startsWith('@') || part.startsWith('http')) {
        return (
          <span key={index} className="preview-highlight-link">
            {part}
          </span>
        );
      }
      return part;
    });
  };

  return (
    <div className="preview-container">
      {/* Preview Header / Tabs */}
      <div className="preview-header">
        <div className="preview-title-group">
          <Eye size={18} className="preview-title-icon" />
          <h3 className="preview-title">Live Social Card Preview</h3>
        </div>

        <div className="preview-platform-tabs">
          <button
            type="button"
            className={`preview-tab-btn ${activePreviewTab === 'twitter' ? 'active-twitter' : ''}`}
            onClick={() => setActivePreviewTab('twitter')}
          >
            Twitter / X Mockup
          </button>
          <button
            type="button"
            className={`preview-tab-btn ${activePreviewTab === 'linkedin' ? 'active-linkedin' : ''}`}
            onClick={() => setActivePreviewTab('linkedin')}
          >
            LinkedIn Mockup
          </button>
        </div>
      </div>

      {/* Preview Content Wrapper */}
      <div className="preview-card-wrapper">

        {/* Twitter Preview Mockup */}
        {activePreviewTab === 'twitter' && (
          <div className="twitter-mockup-card">
            {/* Top Row: Avatar, Name, Handle, Timestamp, Menu */}
            <div className="mockup-author-row">
              <img 
                src={config.author.avatar} 
                alt="Alex Rivera" 
                className="mockup-avatar" 
              />
              <div className="mockup-author-info">
                <div className="author-name-line">
                  <span className="author-display-name">{config.author.name}</span>
                  <BadgeCheck size={16} className="verified-badge-blue" />
                  <span className="author-handle">{config.author.handle}</span>
                  <span className="bullet-sep">·</span>
                  <span className="post-timestamp">Just now</span>
                </div>
              </div>
              <button type="button" className="mockup-menu-btn" title="Options">
                <MoreHorizontal size={16} />
              </button>
            </div>

            {/* Post Content Body */}
            <div className="mockup-body twitter-body">
              <p className="mockup-text">{formatContent(postText)}</p>
            </div>

            {/* Status if overflow */}
            {isOverLimit && (
              <div className="preview-warning-tag">
                ⚠️ Exceeds 280-char limit for Twitter ({postText.length} chars)
              </div>
            )}

            {/* Twitter Engagement Actions */}
            <div className="mockup-engagement-bar twitter-engagement">
              <button type="button" className="eng-btn eng-comment" title="Reply">
                <MessageCircle size={17} />
                <span>18</span>
              </button>
              <button type="button" className="eng-btn eng-retweet" title="Repost">
                <Repeat2 size={17} />
                <span>7</span>
              </button>
              <button 
                type="button" 
                className={`eng-btn eng-like ${liked ? 'liked' : ''}`} 
                onClick={handleToggleLike}
                title="Like"
              >
                <Heart size={17} fill={liked ? '#f91880' : 'none'} color={liked ? '#f91880' : 'currentColor'} />
                <span>{likeCount}</span>
              </button>
              <button type="button" className="eng-btn eng-bookmark" title="Bookmark">
                <Bookmark size={17} />
              </button>
              <button type="button" className="eng-btn eng-share" title="Share">
                <Share size={17} />
              </button>
            </div>
          </div>
        )}

        {/* LinkedIn Preview Mockup */}
        {activePreviewTab === 'linkedin' && (
          <div className="linkedin-mockup-card">
            {/* Author Row */}
            <div className="mockup-author-row">
              <img 
                src={config.author.avatar} 
                alt="Alex Rivera" 
                className="mockup-avatar" 
              />
              <div className="mockup-author-info">
                <div className="author-name-line">
                  <span className="author-display-name">{config.author.name}</span>
                  <span className="connection-degree">• 1st</span>
                </div>
                <div className="author-headline">{config.author.tagline}</div>
                <div className="post-meta-sub">
                  <span>Just now</span>
                  <span className="bullet-sep">•</span>
                  <Globe size={13} className="globe-icon" />
                </div>
              </div>
              <button type="button" className="mockup-menu-btn" title="Options">
                <MoreHorizontal size={16} />
              </button>
            </div>

            {/* Post Content Body */}
            <div className="mockup-body linkedin-body">
              <p className="mockup-text">{formatContent(postText)}</p>
            </div>

            {/* Status if overflow */}
            {isOverLimit && (
              <div className="preview-warning-tag">
                ⚠️ Exceeds 3,000-char limit for LinkedIn ({postText.length} chars)
              </div>
            )}

            {/* LinkedIn Reactions Counter Bar */}
            <div className="linkedin-stats-bar">
              <div className="reaction-icons-group">
                <span className="reaction-bubble bubble-like">👍</span>
                <span className="reaction-bubble bubble-heart">❤️</span>
                <span className="reaction-bubble bubble-insight">💡</span>
                <span className="reaction-count-text">{likeCount + 15}</span>
              </div>
              <div className="comments-reposts-text">
                <span>12 comments</span>
                <span>•</span>
                <span>4 reposts</span>
              </div>
            </div>

            {/* LinkedIn Action Buttons */}
            <div className="mockup-engagement-bar linkedin-engagement">
              <button 
                type="button" 
                className={`li-action-btn ${liked ? 'liked' : ''}`}
                onClick={handleToggleLike}
              >
                <ThumbsUp size={18} fill={liked ? '#0a66c2' : 'none'} color={liked ? '#0a66c2' : 'currentColor'} />
                <span>{liked ? 'Liked' : 'Like'}</span>
              </button>
              <button type="button" className="li-action-btn">
                <MessageSquare size={18} />
                <span>Comment</span>
              </button>
              <button type="button" className="li-action-btn">
                <Repeat2 size={18} />
                <span>Repost</span>
              </button>
              <button type="button" className="li-action-btn">
                <SendIcon size={18} />
                <span>Send</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
