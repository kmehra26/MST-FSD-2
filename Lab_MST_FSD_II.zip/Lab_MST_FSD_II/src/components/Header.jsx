import React from 'react';
import { Send } from 'lucide-react';

export default function Header() {
  return (
    <header className="app-header">
      <div className="header-container">
        <div className="brand-group">
          <div className="brand-icon-wrapper">
            <Send className="brand-icon" size={24} />
          </div>
          <div className="brand-text">
            <h1 className="brand-title">
              Post <span className="gradient-text">Composer</span>
            </h1>
            <p className="brand-subtitle">
              Craft & validate social content with instant character limits
            </p>
          </div>
        </div>

        <div className="header-badges">
          <div className="platform-limit-chip twitter-chip">
            <span className="chip-dot"></span>
            <span className="chip-platform">Twitter / X</span>
            <span className="chip-limit">280 chars</span>
          </div>

          <div className="platform-limit-chip linkedin-chip">
            <span className="chip-dot"></span>
            <span className="chip-platform">LinkedIn</span>
            <span className="chip-limit">3,000 chars</span>
          </div>
        </div>
      </div>
    </header>
  );
}
