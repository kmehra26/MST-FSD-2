import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { TwitterIcon, LinkedInIcon } from './Icons';

export default function PlatformSelector({ selectedPlatform, onSelectPlatform }) {
  return (
    <div className="platform-selector-card">
      <div className="selector-header">
        <label className="selector-label">Select Target Platform</label>
        <span className="selector-hint">Select a network to apply character constraints</span>
      </div>

      <div className="platform-options" role="radiogroup" aria-label="Target Platform Selection">
        {/* Twitter / X Option */}
        <button
          type="button"
          role="radio"
          aria-checked={selectedPlatform === 'twitter'}
          id="select-twitter-btn"
          className={`platform-btn twitter-btn ${selectedPlatform === 'twitter' ? 'active' : ''}`}
          onClick={() => onSelectPlatform('twitter')}
        >
          <div className="platform-btn-content">
            <div className="platform-icon-circle twitter-circle">
              <TwitterIcon size={19} />
            </div>
            <div className="platform-info">
              <span className="platform-name">Twitter / X</span>
              <span className="platform-limit-tag">280 character limit</span>
            </div>
          </div>
          {selectedPlatform === 'twitter' && (
            <div className="active-badge twitter-badge">
              <CheckCircle2 size={16} />
              <span>Active</span>
            </div>
          )}
        </button>

        {/* LinkedIn Option */}
        <button
          type="button"
          role="radio"
          aria-checked={selectedPlatform === 'linkedin'}
          id="select-linkedin-btn"
          className={`platform-btn linkedin-btn ${selectedPlatform === 'linkedin' ? 'active' : ''}`}
          onClick={() => onSelectPlatform('linkedin')}
        >
          <div className="platform-btn-content">
            <div className="platform-icon-circle linkedin-circle">
              <LinkedInIcon size={19} />
            </div>
            <div className="platform-info">
              <span className="platform-name">LinkedIn</span>
              <span className="platform-limit-tag">3,000 character limit</span>
            </div>
          </div>
          {selectedPlatform === 'linkedin' && (
            <div className="active-badge linkedin-badge">
              <CheckCircle2 size={16} />
              <span>Active</span>
            </div>
          )}
        </button>
      </div>
    </div>
  );
}
