import React, { useRef } from 'react';
import { 
  AlertCircle, 
  CheckCircle, 
  Copy, 
  Check, 
  Trash2, 
  Sparkles, 
  Hash, 
  Smile, 
  Share2,
  FileText,
  Clock
} from 'lucide-react';
import { PLATFORMS, SAMPLE_POSTS } from '../constants/platforms';
import PlatformSelector from './PlatformSelector';

export default function PostComposer({
  postText,
  setPostText,
  selectedPlatform,
  setSelectedPlatform,
  onCopy,
  copied,
  onClear
}) {
  const textareaRef = useRef(null);
  const currentConfig = PLATFORMS[selectedPlatform];
  const charLimit = currentConfig.limit;
  const charCount = postText.length;
  const isOverLimit = charCount > charLimit;
  const charactersRemaining = charLimit - charCount;
  const excessCharacters = charCount - charLimit;
  
  // Calculate progress percentage (clamped for visual indicators)
  const percentage = Math.min((charCount / charLimit) * 100, 100);
  const isWarning = !isOverLimit && percentage >= 80;

  // Calculate word count and estimated reading time
  const trimmedText = postText.trim();
  const wordCount = trimmedText ? trimmedText.split(/\s+/).length : 0;
  const readTimeSeconds = Math.max(1, Math.ceil((wordCount / 200) * 60));

  // Determine progress ring color
  const getProgressColor = () => {
    if (isOverLimit) return 'var(--danger-color)';
    if (isWarning) return 'var(--warning-color)';
    return currentConfig.accentColor;
  };

  // Circular progress calculations for SVG ring
  const circleRadius = 18;
  const circumference = 2 * Math.PI * circleRadius;
  const strokeDashoffset = circumference - (Math.min(percentage, 100) / 100) * circumference;

  // Quick insertion helpers
  const handleInsertTag = (tag) => {
    const separator = postText && !postText.endsWith(' ') && !postText.endsWith('\n') ? ' ' : '';
    setPostText(prev => prev + separator + tag);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleLoadSample = (sampleKey) => {
    if (sampleKey === 'twitterShort') {
      setSelectedPlatform('twitter');
      setPostText(SAMPLE_POSTS.twitterShort);
    } else if (sampleKey === 'twitterOverflow') {
      setSelectedPlatform('twitter');
      setPostText(SAMPLE_POSTS.twitterOverflow);
    } else if (sampleKey === 'linkedinStory') {
      setSelectedPlatform('linkedin');
      setPostText(SAMPLE_POSTS.linkedinStory);
    }
  };

  return (
    <div className="composer-container">
      {/* Platform Selector */}
      <PlatformSelector 
        selectedPlatform={selectedPlatform} 
        onSelectPlatform={setSelectedPlatform} 
      />

      {/* Main Composer Box */}
      <div className={`composer-card ${isOverLimit ? 'has-error' : ''} ${isWarning ? 'has-warning' : ''}`}>
        
        {/* Composer Card Header / Toolbar */}
        <div className="composer-toolbar">
          <div className="toolbar-left">
            <span className="platform-indicator-pill" style={{ '--pill-color': currentConfig.accentColor }}>
              <span className="pill-dot"></span>
              Drafting for {currentConfig.name}
            </span>
          </div>

          <div className="toolbar-right">
            {/* Quick Sample Presets */}
            <div className="sample-presets">
              <span className="presets-label">
                <Sparkles size={14} /> Samples:
              </span>
              <button 
                type="button" 
                className="preset-btn"
                onClick={() => handleLoadSample('twitterShort')}
                title="Load a valid Tweet sample"
              >
                Tweet
              </button>
              <button 
                type="button" 
                className="preset-btn"
                onClick={() => handleLoadSample('twitterOverflow')}
                title="Load a post that exceeds Twitter's 280 character limit"
              >
                Overflow Test
              </button>
              <button 
                type="button" 
                className="preset-btn"
                onClick={() => handleLoadSample('linkedinStory')}
                title="Load a rich LinkedIn post sample"
              >
                LinkedIn Story
              </button>
            </div>
          </div>
        </div>

        {/* Textarea Input Area */}
        <div className="textarea-wrapper">
          <textarea
            ref={textareaRef}
            id="post-textarea"
            name="postContent"
            className={`post-textarea ${isOverLimit ? 'textarea-error' : ''}`}
            placeholder={currentConfig.placeholder}
            value={postText}
            onChange={(e) => setPostText(e.target.value)}
            rows={8}
            aria-invalid={isOverLimit}
            aria-describedby="char-count-status error-message-banner"
          />
        </div>

        {/* Dynamic Error Message Banner (When character limit is exceeded) */}
        {isOverLimit && (
          <div 
            id="error-message-banner" 
            className="error-banner animate-shake" 
            role="alert"
            aria-live="assertive"
          >
            <div className="error-banner-icon">
              <AlertCircle size={20} />
            </div>
            <div className="error-banner-content">
              <h4 className="error-title">
                Character Limit Exceeded for {currentConfig.name}!
              </h4>
              <p className="error-desc">
                Your post contains <strong>{charCount.toLocaleString()}</strong> characters, which exceeds the{' '}
                <strong>{charLimit.toLocaleString()}</strong> character limit by{' '}
                <span className="excess-highlight">{excessCharacters.toLocaleString()} character{excessCharacters === 1 ? '' : 's'}</span>. 
                Please reduce the text length to publish to {currentConfig.shortName}.
              </p>
            </div>
          </div>
        )}

        {/* Warning Banner when approaching limit (>= 80%) */}
        {isWarning && !isOverLimit && (
          <div className="warning-banner" role="status">
            <AlertCircle size={16} />
            <span>
              Approaching limit: <strong>{charactersRemaining}</strong> characters remaining ({Math.round(percentage)}% used).
            </span>
          </div>
        )}

        {/* Bottom Status Bar: Character Count & Live Metrics */}
        <div className="composer-statusbar">
          {/* Left: Quick Insertion Pills & Stats */}
          <div className="stats-group">
            <div className="metric-item" title="Word count">
              <FileText size={15} />
              <span>{wordCount} {wordCount === 1 ? 'word' : 'words'}</span>
            </div>
            <div className="metric-item" title="Estimated reading time">
              <Clock size={15} />
              <span>{readTimeSeconds}s read</span>
            </div>
            
            {/* Quick Hashtag Inserters */}
            <div className="hashtag-chips">
              <button 
                type="button" 
                className="tag-chip" 
                onClick={() => handleInsertTag('#ReactJS')}
                title="Add #ReactJS"
              >
                #ReactJS
              </button>
              <button 
                type="button" 
                className="tag-chip" 
                onClick={() => handleInsertTag('#WebDev')}
                title="Add #WebDev"
              >
                #WebDev
              </button>
              <button 
                type="button" 
                className="tag-chip" 
                onClick={() => handleInsertTag('#Tech')}
                title="Add #Tech"
              >
                #Tech
              </button>
            </div>
          </div>

          {/* Right: Real-time Character Counter & Circular Progress Indicator */}
          <div className="counter-group" id="char-count-status">
            {/* Circular Progress Meter */}
            <div className="circular-meter" title={`${percentage.toFixed(1)}% of character limit used`}>
              <svg width="44" height="44" viewBox="0 0 44 44">
                <circle
                  className="meter-bg"
                  cx="22"
                  cy="22"
                  r={circleRadius}
                  strokeWidth="3.5"
                />
                <circle
                  className="meter-fill"
                  cx="22"
                  cy="22"
                  r={circleRadius}
                  strokeWidth="3.5"
                  strokeDasharray={circumference}
                  strokeDashoffset={isOverLimit ? 0 : strokeDashoffset}
                  style={{
                    stroke: getProgressColor(),
                    transform: 'rotate(-90deg)',
                    transformOrigin: '50% 50%',
                    transition: 'stroke-dashoffset 0.2s ease, stroke 0.2s ease'
                  }}
                />
              </svg>
              <span 
                className="meter-percentage"
                style={{ color: getProgressColor() }}
              >
                {isOverLimit ? '!' : `${Math.round(percentage)}%`}
              </span>
            </div>

            {/* Numeric Character Count Displays */}
            <div className="char-digits">
              <div className={`char-main-count ${isOverLimit ? 'text-danger' : isWarning ? 'text-warning' : 'text-primary'}`}>
                <span className="current-chars">{charCount.toLocaleString()}</span>
                <span className="separator">/</span>
                <span className="limit-chars">{charLimit.toLocaleString()}</span>
              </div>
              <div className={`char-remaining ${isOverLimit ? 'remaining-danger' : 'remaining-muted'}`}>
                {isOverLimit ? (
                  <span>+{excessCharacters.toLocaleString()} over limit</span>
                ) : (
                  <span>{charactersRemaining.toLocaleString()} remaining</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Visual Linear Progress Bar */}
        <div className="progress-bar-track">
          <div 
            className="progress-bar-fill" 
            style={{ 
              width: `${percentage}%`,
              backgroundColor: getProgressColor()
            }}
          />
        </div>

        {/* Action Controls Bar */}
        <div className="composer-actions">
          <div className="actions-left">
            <button
              type="button"
              id="clear-btn"
              className="btn btn-ghost"
              onClick={onClear}
              disabled={!postText}
              title="Clear composer textarea"
            >
              <Trash2 size={16} />
              <span>Clear</span>
            </button>
          </div>

          <div className="actions-right">
            <button
              type="button"
              id="copy-btn"
              className={`btn btn-secondary ${copied ? 'btn-copied' : ''}`}
              onClick={onCopy}
              disabled={!postText}
              title="Copy post content to clipboard"
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              <span>{copied ? 'Copied!' : 'Copy Text'}</span>
            </button>

            <button
              type="button"
              id="publish-btn"
              className={`btn btn-primary ${isOverLimit ? 'btn-disabled' : ''}`}
              style={{
                '--btn-accent': currentConfig.accentColor,
                '--btn-hover': currentConfig.secondaryColor
              }}
              disabled={!postText || isOverLimit}
              title={
                !postText 
                  ? 'Type some text first' 
                  : isOverLimit 
                    ? `Cannot publish: exceeds ${charLimit} character limit` 
                    : `Simulate publishing to ${currentConfig.name}`
              }
              onClick={() => {
                alert(`🚀 Post ready for ${currentConfig.name}!\n\nCharacters: ${charCount}/${charLimit}\n\nContent:\n"${postText}"`);
              }}
            >
              <Share2 size={16} />
              <span>Publish to {currentConfig.shortName}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
