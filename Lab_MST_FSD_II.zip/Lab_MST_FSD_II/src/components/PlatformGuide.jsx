import React from 'react';
import { HelpCircle, Check, Info, Zap } from 'lucide-react';
import { PLATFORMS } from '../constants/platforms';

export default function PlatformGuide({ selectedPlatform }) {
  const config = PLATFORMS[selectedPlatform];

  return (
    <div className="guide-card">
      <div className="guide-header">
        <Zap size={18} className="guide-icon" />
        <h3 className="guide-title">{config.name} Best Practices</h3>
      </div>

      <div className="guide-content">
        <div className="guide-stat-row">
          <div className="guide-stat-pill">
            <span className="stat-label">Hard Limit</span>
            <span className="stat-value">{config.limit.toLocaleString()} characters</span>
          </div>
          <div className="guide-stat-pill">
            <span className="stat-label">Ideal Length</span>
            <span className="stat-value">{selectedPlatform === 'twitter' ? '70–120 chars' : '1,200–1,800 chars'}</span>
          </div>
        </div>

        <ul className="tips-list">
          {config.tips.map((tip, idx) => (
            <li key={idx} className="tip-item">
              <Check size={16} className="tip-check-icon" />
              <span>{tip}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
