export const PLATFORMS = {
  twitter: {
    id: 'twitter',
    name: 'Twitter / X',
    shortName: 'Twitter',
    limit: 280,
    accentColor: '#1d9bf0',
    secondaryColor: '#0c7abf',
    bgLight: 'rgba(29, 155, 240, 0.1)',
    borderHover: 'rgba(29, 155, 240, 0.4)',
    placeholder: "What's happening? Share a concise thought, tip, or update under 280 characters...",
    author: {
      name: 'Alex Rivera',
      handle: '@alexrivera_dev',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      tagline: 'Building next-gen web apps ✨'
    },
    tips: [
      'Keep it punchy: Tweets with 70–100 characters get highest engagement.',
      'Use 1–2 relevant hashtags for discoverability.',
      'Threads work well if your content exceeds 280 characters.'
    ]
  },
  linkedin: {
    id: 'linkedin',
    name: 'LinkedIn',
    shortName: 'LinkedIn',
    limit: 3000,
    accentColor: '#0a66c2',
    secondaryColor: '#004182',
    bgLight: 'rgba(10, 102, 194, 0.1)',
    borderHover: 'rgba(10, 102, 194, 0.4)',
    placeholder: "What do you want to talk about? Share an industry insight, milestone, story, or article...",
    author: {
      name: 'Alex Rivera',
      handle: 'Alex Rivera • 1st',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      tagline: 'Lead Full Stack Engineer | React & Cloud Architect | Tech Speaker'
    },
    tips: [
      'Hook the reader in the first 2 lines before the "see more" cutoff.',
      'Break text into short, scannable paragraphs with line breaks.',
      'Add a question at the end to drive meaningful conversation.'
    ]
  }
};

export const SAMPLE_POSTS = {
  twitterShort: "Excited to unveil our new open-source developer toolkit! 🚀\n\nFast, lightweight, and built with modern React 18 & Vite. Check it out and let me know your thoughts! 👇\n\n#webdev #reactjs #opensource #buildinpublic",
  twitterOverflow: "Today we had an incredible workshop diving deep into Full Stack React development, state management, asynchronous data fetching, edge serverless functions, database optimizations, responsive UI/UX architecture, performance benchmarking, web accessibility compliance, and continuous deployment pipelines across multi-cloud environments. The energy from every single engineer was unbelievable! Make sure to stay tuned for our next session next week.",
  linkedinStory: "💡 3 Lessons I learned refactoring a legacy monolith into modern React components:\n\n1. Start with the leaf components\nDon't try to rewrite everything at once. Isolate atomic design tokens and build bottom-up.\n\n2. Type-safety is your safety net\nStrict typing catches 80% of edge cases before code ever hits testing.\n\n3. Optimize for readability over cleverness\nCode is read 10x more often than it is written. Clean component contracts save months of maintenance.\n\nWhat is your biggest takeaway from large-scale frontend refactoring?\n\n#SoftwareEngineering #WebDevelopment #ReactJS #CleanCode #TechLeadership"
};
