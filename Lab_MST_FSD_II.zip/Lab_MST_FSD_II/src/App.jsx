import React, { useState } from 'react';
import Header from './components/Header';
import PostComposer from './components/PostComposer';
import SocialPreview from './components/SocialPreview';
import PlatformGuide from './components/PlatformGuide';
import Toast from './components/Toast';

export default function App() {
  const [selectedPlatform, setSelectedPlatform] = useState('twitter');
  const [postText, setPostText] = useState(
    "Excited to unveil our new open-source developer toolkit! 🚀\n\nFast, lightweight, and built with modern React 18 & Vite. Check it out and let me know your thoughts! 👇\n\n#webdev #reactjs #opensource #buildinpublic"
  );
  const [copied, setCopied] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [showToast, setShowToast] = useState(false);

  const triggerToast = (msg) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 3000);
  };

  const handleCopy = async () => {
    if (!postText) return;
    try {
      await navigator.clipboard.writeText(postText);
      setCopied(true);
      triggerToast('Copied post content to clipboard! 📋');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = postText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      triggerToast('Copied to clipboard! 📋');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClear = () => {
    if (!postText) return;
    setPostText('');
    triggerToast('Cleared composer text 🗑️');
  };

  return (
    <div className="app-layout">
      {/* Toast Notification */}
      <Toast message={toastMessage} visible={showToast} />

      {/* Main Container */}
      <div className="app-wrapper">
        <Header />

        <main className="main-content">
          {/* Main Grid: Left = Post Composer, Right = Preview & Guide */}
          <div className="composer-grid">
            
            {/* Primary Column: Composer */}
            <section className="composer-column" aria-label="Post Composer Form">
              <PostComposer
                postText={postText}
                setPostText={setPostText}
                selectedPlatform={selectedPlatform}
                setSelectedPlatform={setSelectedPlatform}
                onCopy={handleCopy}
                copied={copied}
                onClear={handleClear}
              />
            </section>

            {/* Secondary Column: Live Preview & Best Practices */}
            <section className="preview-column" aria-label="Social Media Live Preview">
              <SocialPreview
                postText={postText}
                selectedPlatform={selectedPlatform}
              />

              <PlatformGuide 
                selectedPlatform={selectedPlatform} 
              />
            </section>

          </div>
        </main>

        <footer className="app-footer">
          <p>
            React Post Composer • Supporting <strong>Twitter / X (280 chars)</strong> & <strong>LinkedIn (3,000 chars)</strong> validation.
          </p>
        </footer>
      </div>
    </div>
  );
}
